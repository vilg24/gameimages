Lightning Boy Sprite Asset (Transparent PNG)

Contents:
- lightning_boy_source.png  (cropped, full resolution)
- lightning_boy_1024.png
- lightning_boy_512.png
- lightning_boy_256.png
- manifest.json

Suggested workflow (Unity/Godot/Unreal):
1) Import PNG(s). Confirm alpha/transparency looks correct.
2) Set texture type to Sprite (2D/UI) where applicable.
3) If you need a single canonical size, use lightning_boy_1024.png.
4) For UI icons/portraits, use 512 or 256.

If you see a faint halo, try enabling "Alpha is Transparency" (Unity) or switch to premultiplied alpha in your renderer.
